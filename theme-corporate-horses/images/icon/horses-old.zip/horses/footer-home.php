		<footer class="footer">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-sm-4 logoFoot">
						<img src="/wp-content/uploads/2021/03/logo-foot.png">
					</div>
					<div class="col-lg-3 visible-lg"></div>
					<div class="col-lg-3 col-sm-4">
						<?php if(!dynamic_sidebar( 'phonev' )): ?>
						<?php endif; ?>
					</div>
					<div class="col-lg-3 col-sm-4 socFoot">
						<?php if(!dynamic_sidebar( 'kontact' )): ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</footer>
		<a id="toTop" class="toTopmi"><i class="fa fa-angle-up"></i></a>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="<?php bloginfo('template_url'); ?>/js/bootstrap.min.js"></script>
	<script src="<?php bloginfo('template_url'); ?>/js/wow.min.js"></script>
	<script src="<?php bloginfo('template_url'); ?>/js/scripts.js"></script>
	<?php wp_footer(); ?>
  </body>
</html>











