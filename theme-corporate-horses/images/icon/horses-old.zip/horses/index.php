<?php get_header(); ?>
		<section class="fotoDay">
			<div class="container">
				<div class="row fotoDayRow">
					<div class="col-lg-8">
						<p class="fotoDayP">фото дня</p>
					</div>
					<div class="col-lg-4 col-sm-6 visible-lg">
						<p class="fotoDayP">відео дня</p>
					</div>
					<div class="col-lg-4 col-sm-6 fotoDayImg">
						<?php echo get_new_royalslider(1); ?>
					</div>
					<div class="col-lg-4 hidden-xs fotoDayImg">
						<?php echo get_new_royalslider(2); ?>
					</div>
					<div class="col-lg-4 visible-lg videoDay fotoDayImg">
						<div class="embed-responsive embed-responsive-16by9">
							<?php
							$id = 33; // номер категории
							$posts_about = new WP_Query(array('cat' => $id, 'posts_per_page' => 1, 'order' => 'DESC'));
							?>
							<?php if ( $posts_about->have_posts() ) : ?>
							<?php while ( $posts_about->have_posts() ) : $posts_about->the_post(); ?>
								<?php the_content(); ?>
							<?php endwhile; ?>
							<?php else: ?>
							<?php endif; ?>
						</div>
					</div>
					
				</div>
			</div>
		</section>
		<section class="content">
			<div class="container">
				<div class="row">
					<?php get_sidebar('left'); ?>
					<main class="col-lg-6 col-sm-8">
						<p class="vidjetTitle vidjetTitleNews">новини</p>
						<section class="newsContent">
						<?php if ( have_posts() ) : $count = 0; while ( have_posts() )  : the_post(); $count++; ?>
							<article class="row rowArticle<?php if ($count % 2 == 0 ) echo ' articleRight'; ?> articleLeft">
								<div class="articleImg">
									<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
								</div>
								<div class="articleText">
									<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
									<div class="articleExcerpt"><?php the_excerpt(); ?></div>
									<a class="btnNews" href="<?php the_permalink(); ?>">читати статтю</a>
								</div>
							</article>
						<?php endwhile; ?>
						<?php endif; ?>							
						</section>
						<div class="wpCorenavi"><?php wp_corenavi(); ?></div>
					</main>
					<?php get_sidebar('right'); ?>
				</div>
			</div>
		</section>
		<section class="maps">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2644.5787610483003!2d35.06360291600815!3d48.48379297925263!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40dbe299e8b11019%3A0x47ddb423008d453c!2z0L_RgNC-0LLRg9C70L7QuiDQm9GO0LHQsNGA0YHRjNC60L7Qs9C-LCAxMiwg0JTQvdGW0L_RgNC-zIEsINCU0L3RltC_0YDQvtC_0LXRgtGA0L7QstGB0YzQutCwINC-0LHQu9Cw0YHRgtGMLCA0OTAwMA!5e0!3m2!1sru!2sua!4v1516442053754" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
					</div>
					<div class="col-lg-5"><p></p></div>
				</div>
			</div>
		</section>		
<?php get_footer(); ?>