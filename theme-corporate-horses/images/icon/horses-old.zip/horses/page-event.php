<?php /* Template Name: Календарь */ ?>
<?php get_header(); ?>
		<section class="content">
			<div class="container">
				<div class="row">
					<main class="col-lg-9 col-sm-8">
						<section class="postContent clearfix">
						<div class="breadcrumb">
							<?php 
							if(function_exists('bcn_display'))
							{ bcn_display(); }
							?>
						</div>
							<h1><?php the_title(); ?></h1>
						
							<div class="section-tabs">
							<!-- Nav tabs -->
							<ul class="nav nav-tabs nav-justified" role="tablist">
								<li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">События списком</a></li>
								<li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Календар змагань на рік</a></li>
							</ul>

							<!-- Tab panes -->
							<div class="tab-content clearfix">
								<div role="tabpanel" class="tab-pane fade in active" id="home">
									<?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
									<article class="post">
										<div class="pageMain">
											<?php the_content(); ?>
										</div>	
									</article>
									<?php endwhile; ?>
									<?php endif; ?> 
								</div>
								<div role="tabpanel" class="tab-pane" id="profile">
									<?php
									$id = 9; // номер категории
									$posts_about = new WP_Query(array('cat' => $id, 'posts_per_page' => 1, 'order' => 'DESC'));
									?>
									<?php if ( $posts_about->have_posts() ) : ?>
									<?php while ( $posts_about->have_posts() ) : $posts_about->the_post(); ?>
									<article class="post">
										<div class="pageMain">
											<?php the_content(); ?>
										</div>	
									</article>
									<?php endwhile; ?>
									<?php else: ?>
									<?php endif; ?> 
									
									
								</div>
							</div>
						</div><!-- /.section-tabs -->
						

						</section>
					

					</main>
					<?php get_sidebar('right'); ?>
				</div>
			</div>
		</section>		
<?php get_footer(); ?>