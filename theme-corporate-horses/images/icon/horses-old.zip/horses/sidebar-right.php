<aside class="col-lg-3 col-sm-4">
	<div class="vidjet">
		<p class="vidjetTitle">готується до виходу</p>
		<?php
		$id = 3; // номер категории
		$posts_about = new WP_Query(array('cat' => $id, 'posts_per_page' => 1, 'order' => 'DESC'));
		?>
		<?php if ( $posts_about->have_posts() ) : ?>
		<?php while ( $posts_about->have_posts() ) : $posts_about->the_post(); ?>
			<a href ="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
		<?php endwhile; ?>
		<?php else: ?>
		<?php endif; ?>
	</div>
	<div class="vidjet hidden-lg">
		<p class="vidjetTitle">останній випуск</p>
		<?php
		$id = 4; // номер категории
		$posts_about = new WP_Query(array('cat' => $id, 'posts_per_page' => 1, 'order' => 'DESC'));
		?>
		<?php if ( $posts_about->have_posts() ) : ?>
		<?php while ( $posts_about->have_posts() ) : $posts_about->the_post(); ?>
			<a href ="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
		<?php endwhile; ?>
		<?php else: ?>
		<?php endif; ?>
	</div>
	<div class="vidjetEvent">
		<?php if(!dynamic_sidebar( 'event' )): ?>
		<?php endif; ?>
		<div class="vidjetEventLink"><a class="btnH" href="/?page_id=88">всі події</a></div>
	</div>
	<div class="vidjet">
		<?php if(!dynamic_sidebar( 'rek-right' )): ?>
		<?php endif; ?>
	</div>
	<div class="vidjet hidden-lg">
		<?php if(!dynamic_sidebar( 'rek-left' )): ?>
		<?php endif; ?>
	</div>
</aside>