<?php get_header(); ?>
		<section class="content">
			<div class="container">
				<div class="row">
					<main class="col-lg-9">
						<section class="postContent clearfix">
							<div class="breadcrumb">
								<?php 
								if(function_exists('bcn_display'))
								{ bcn_display(); }
								?>
							</div>
							<article class="post">
								<h1>404. Сторінка не знайдена</h1>
								<div class="pageMain">
									<p class="zagolov" style="text-align: center;"> 404. Сторінка не знайдена</p>
								</div>	
							</article>
						</section>
					</main>
					<?php get_sidebar('right'); ?>
				</div>
			</div>
		</section>		
<?php get_footer(); ?>