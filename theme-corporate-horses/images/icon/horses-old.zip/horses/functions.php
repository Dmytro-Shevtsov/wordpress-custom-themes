<?php
/* загружаемые скрипты и стили */
function load_style_script(){
	wp_enqueue_style('bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css');
	wp_enqueue_style('font-awesome', get_template_directory_uri() . '/css/font-awesome/css/font-awesome.min.css');
	wp_enqueue_style('animate', get_template_directory_uri() . '/css/animate.css');
	wp_enqueue_style('style', get_template_directory_uri() . '/style.css');
}

/* загружаем скрипты и стили */
add_action('wp_enqueue_scripts', 'load_style_script');

/* поддержка миниатюр */
add_theme_support('post-thumbnails');

/* регистрируем меню */
register_nav_menus(array(
	'header_menu' => 'Меню в шапке'
));

/* скрываем рубрики на главной */
function exclude_category($query) {
 if ($query->is_home){
 $query->set('cat','-32, -13, -5, -10, -11, -12, -7, -3, -4, -33, -9');} 
 return $query; }
add_filter('pre_get_posts','exclude_category');

/* Виджет  Календарь*/
register_sidebar(array(
		'name' => 'Календарь',
		'id' => 'event',
		'before_widget' => '',
		'after_widget' => ''
	)
);

/* Виджет телефоны */
register_sidebar(array(
		'name' => 'Телефоны',
		'id' => 'phonev',
		'before_widget' => '',
		'after_widget' => ''
	)
);

/* Виджет контакты */
register_sidebar(array(
		'name' => 'Контакты',
		'id' => 'kontact',
		'before_widget' => '',
		'after_widget' => ''
	)
);

/* Виджет webpr */
register_sidebar(array(
		'name' => 'web',
		'id' => 'webpr',
		'before_widget' => '',
		'after_widget' => ''
	)
);

/* Реклама в шапке */
register_sidebar(array(
		'name' => 'Реклама в шапке',
		'id' => 'rek-head',
		'before_widget' => '',
		'after_widget' => ''
	)
);

/* Реклама левый блок */
register_sidebar(array(
		'name' => 'Реклама левый блок',
		'id' => 'rek-left',
		'before_widget' => '',
		'after_widget' => ''
	)
);

/* Реклама правый блок */
register_sidebar(array(
		'name' => 'Реклама правый блок',
		'id' => 'rek-right',
		'before_widget' => '',
		'after_widget' => ''
	)
);

/* пагинация */
function wp_corenavi(){
	global $wp_query, $wp_rewrite;
	$pages = '';
	$max = $wp_query->max_num_pages;
	if (!$current = get_query_var('paged')) $current = 1;
	$a['base'] = str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999)));
	$a['total'] = $max;
	$a['current'] = $current;

	$total = 0; //1 - выводить текст "Страница N из N", 0 - не выводить
	$a['mid_size'] = 2; //сколько ссылок показывать слева и справа от текущей
	$a['end_size'] = 1; //сколько ссылок показывать в начале и в конце
	$a['prev_text'] = '&laquo;'; //текст ссылки "Предыдущая страница"
	$a['next_text'] = '&raquo;'; //текст ссылки "Следующая страница"

	if ($max > 1) echo '<div class="pager">';
	if ($total == 1 && $max > 1) $pages = '<span class="pages">Страница ' . $current . ' из ' . $max . '</span>'."\r\n";
	echo $pages . paginate_links($a);
	if ($max > 1) echo '</div>';
}

/* отключение обновлений */


?>