<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php bloginfo('name'); wp_title(); ?></title>
	<link href="https://fonts.googleapis.com/css?family=Oswald:400,700|PT+Sans:400,400i,700,700i&amp;subset=cyrillic" rel="stylesheet">
	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	  <![endif]-->
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112744057-1"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'UA-112744057-1');
	</script>
	<?php wp_head(); ?>
</head>
<body>	
	<div id="fb-root"></div>
	<script>(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) return;
	  js = d.createElement(s); js.id = id;
	  js.src = 'https://connect.facebook.net/ru_RU/sdk.js#xfbml=1&version=v2.11';
	  fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));</script>
		<header class="header">
			<div class="container">
				<div class="row">
					<div class="col-sm-7 colHeader">
						<div class="colLogoHeader">
							<a href="/"><img src="/wp-content/uploads/2021/03/logo-head.png"></a>
						</div>
					</div>
					<div class="col-sm-5 colBann">
						<div class="colBannerHeader">
							<?php if(!dynamic_sidebar( 'rek-head' )): ?>
							<?php endif; ?>
						</div>
					</div>
					<nav class="col-lg-12">
						<?php wp_nav_menu( array( 'theme_location' => 'header_menu' ) ); ?>
					</nav>
				</div>
			</div>
		</header>