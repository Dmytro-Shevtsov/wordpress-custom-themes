<?php get_header(); ?>
		<section class="content">
			<div class="container">
				<main>
					<div class="divCatTitle">
						<p class="vidjetTitle"><?php single_cat_title(); ?></p>
						<div class="breadcrumb breadcrumbCat">
							<?php 
							if(function_exists('bcn_display'))
							{ bcn_display(); }
							?>
						</div>
					</div>
					<section class="row">
						<?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
						<article class="col-md-4 col-sm-6">
							<div class="postArhiv">
								<div class="postArhivImg">
									<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
								</div>
							</div>	
						</article>
						<?php endwhile; ?>
						<?php endif; ?> 
					</section>
					<div class="wpCorenavi"><?php wp_corenavi(); ?></div>
				</main>
			</div>
		</section>		
<?php get_footer(); ?>