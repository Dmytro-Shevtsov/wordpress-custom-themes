<?php /* Template Name: Контакты */ ?>
<?php get_header(); ?>
		<section class="content">
			<div class="container">
				<div class="row">
					<main class="col-lg-9 col-sm-8">
						<section class="postContent clearfix">
							<div class="breadcrumb">
								<?php 
								if(function_exists('bcn_display'))
								{ bcn_display(); }
								?>
							</div>
							
							<article class="row post">
							<div class="col-lg-12"><h1><?php the_title(); ?></h1></div>
							<div class="col-md-6">
								<?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
								<div class="pageMain" style="margin-bottom:15px;">
									<?php the_content(); ?>
								</div>
								<?php endwhile; ?>
								<?php endif; ?> 
							</div>
							<div class="col-md-6">
								<?php echo do_shortcode('[contact-form-7 id="320"]'); ?>
							</div>	
								<div class="map">
									<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2644.5787610483003!2d35.06360291600815!3d48.48379297925263!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40dbe299e8b11019%3A0x47ddb423008d453c!2z0L_RgNC-0LLRg9C70L7QuiDQm9GO0LHQsNGA0YHRjNC60L7Qs9C-LCAxMiwg0JTQvdGW0L_RgNC-zIEsINCU0L3RltC_0YDQvtC_0LXRgtGA0L7QstGB0YzQutCwINC-0LHQu9Cw0YHRgtGMLCA0OTAwMA!5e0!3m2!1sru!2sua!4v1516442053754" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
								</div>
							</article>
						</section>
					</main>
					<?php get_sidebar('right'); ?>
				</div>
			</div>
		</section>	
<!--
<ul class="ul-cont">
 	<li class="cont-tel"><a href="tel:+380972190837"><i class="fa fa-phone"></i> +38 (097) 219-08-37</a></li>
 	<li class="cont-tel"><a href="tel:+380503226881"><i class="fa fa-phone"></i> +38 (050) 322-68-81</a></li>
 	<li class="cont-tel"><a href="mailto:fksdnepr2@gmail.com"><i class="fa fa-envelope"></i> fksdnepr2@gmail.com</a></li>
	<li class="cont-tel"><a href="mailto:osam1171@gmail.com"><i class="fa fa-envelope"></i> osam1171@gmail.com</a></li>
 	<li class="li-cont-soc"><a href="https://www.facebook.com/horses.ukraine/" target="_blank"><i class="fa fa-facebook-square"></i></a><a href="https://www.instagram.com/horses.dp.ua/" target="_blank"><i class="fa fa-instagram"></i></a><a href="https://www.youtube.com/channel/UCT3QuIMva4Npyoio8nOK_GQ" target="_blank"><i class="fa fa-youtube-play"></i></a></li>
</ul>
-->		
<?php get_footer(); ?>