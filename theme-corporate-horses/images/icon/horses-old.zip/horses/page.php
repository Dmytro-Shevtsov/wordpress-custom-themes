<?php get_header(); ?>
		<section class="content">
			<div class="container">
				<div class="row">
					<main class="col-lg-9 col-sm-8">
						<section class="postContent clearfix">
							<div class="breadcrumb">
								<?php 
								if(function_exists('bcn_display'))
								{ bcn_display(); }
								?>
							</div>
							<?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
							<article class="post">
								<h1><?php the_title(); ?></h1>
								<div class="pageMain">
									<?php the_content(); ?>
								</div>	
							</article>
							<?php endwhile; ?>
							<?php endif; ?> 
						</section>
					</main>
					<?php get_sidebar('right'); ?>
				</div>
			</div>
		</section>		
<?php get_footer(); ?>