<aside class="col-lg-3 visible-lg">
	<div class="vidjet">
		<p class="vidjetTitle">останній випуск</p>
		<?php
		$id = 4; // номер категории
		$posts_about = new WP_Query(array('cat' => $id, 'posts_per_page' => 1, 'order' => 'DESC'));
		?>
		<?php if ( $posts_about->have_posts() ) : ?>
		<?php while ( $posts_about->have_posts() ) : $posts_about->the_post(); ?>
			<a href ="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
		<?php endwhile; ?>
		<?php else: ?>
		<?php endif; ?>
	</div>
	<div class="vidjet">
		<p class="vidjetTitle">Приєднуйтесь</p>
		<div class="fb-page" data-href="https://www.facebook.com/horses.ukraine/" data-tabs="timeline" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/horses.ukraine/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/horses.ukraine/">Horses Ukraine</a></blockquote></div>
	</div>
	<div class="vidjet">
		<?php if(!dynamic_sidebar( 'rek-left' )): ?>
		<?php endif; ?>
	</div>
</aside>