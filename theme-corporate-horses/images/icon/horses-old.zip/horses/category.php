<?php get_header(); ?>
		<section class="content">
			<div class="container">
				<div class="row">
					<?php get_sidebar('left'); ?>
					<main class="col-lg-6 col-sm-8">
						<div class="divCatTitle">
							<p class="vidjetTitle"><?php single_cat_title(); ?></p>
							<div class="breadcrumb breadcrumbCat">
								<?php 
								if(function_exists('bcn_display'))
								{ bcn_display(); }
								?>
							</div>
						</div>
						<section class="newsContent">
							<?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
							<article class="row catCont">
								<div class="col-lg-5 catContImg">
									<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
								</div>
								<div class="col-lg-7 catContText">
									<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
									<div class="catExp"><?php the_excerpt(); ?></div>
									<a class="btnNews" href="<?php the_permalink(); ?>">читати статтю</a>
								</div>
							</article>
							<?php endwhile; ?>
							<?php endif; ?> 
						</section>
						<div class="wpCorenavi"><?php wp_corenavi(); ?></div>
					</main>
					<?php get_sidebar('right'); ?>
				</div>
			</div>
		</section>		
<?php get_footer(); ?>